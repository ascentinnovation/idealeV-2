import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-habilete',
  templateUrl: './habilete.component.html',
  styleUrls: ['./habilete.component.scss']
})
export class HabileteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
