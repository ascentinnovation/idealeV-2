import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confort',
  templateUrl: './confort.component.html',
  styleUrls: ['./confort.component.scss']
})
export class ConfortComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
