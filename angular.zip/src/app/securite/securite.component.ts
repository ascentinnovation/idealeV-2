import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-securite',
  templateUrl: './securite.component.html',
  styleUrls: ['./securite.component.scss']
})
export class SecuriteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
