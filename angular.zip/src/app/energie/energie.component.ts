import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-energie',
  templateUrl: './energie.component.html',
  styleUrls: ['./energie.component.scss']
})
export class EnergieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
