import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asiaaustationinfo',
  templateUrl: './asiaaustationinfo.component.html',
  styleUrls: ['./asiaaustationinfo.component.scss']
})
export class AsiaaustationinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
