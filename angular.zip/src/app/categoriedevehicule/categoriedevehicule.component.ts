import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categoriedevehicule',
  templateUrl: './categoriedevehicule.component.html',
  styleUrls: ['./categoriedevehicule.component.scss']
})
export class CategoriedevehiculeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
