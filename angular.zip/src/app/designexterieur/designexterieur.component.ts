import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-designexterieur',
  templateUrl: './designexterieur.component.html',
  styleUrls: ['./designexterieur.component.scss']
})
export class DesignexterieurComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
