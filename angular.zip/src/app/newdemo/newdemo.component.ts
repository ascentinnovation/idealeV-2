import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newdemo',
  templateUrl: './newdemo.component.html',
  styleUrls: ['./newdemo.component.scss']
})
export class NewdemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
