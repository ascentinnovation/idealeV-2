import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siege',
  templateUrl: './siege.component.html',
  styleUrls: ['./siege.component.scss']
})
export class SiegeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
