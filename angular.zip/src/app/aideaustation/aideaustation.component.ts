import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aideaustation',
  templateUrl: './aideaustation.component.html',
  styleUrls: ['./aideaustation.component.scss']
})
export class AideaustationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
