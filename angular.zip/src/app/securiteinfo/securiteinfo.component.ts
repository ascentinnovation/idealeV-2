import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-securiteinfo',
  templateUrl: './securiteinfo.component.html',
  styleUrls: ['./securiteinfo.component.scss']
})
export class SecuriteinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
