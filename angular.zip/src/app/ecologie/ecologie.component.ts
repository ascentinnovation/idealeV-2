import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ecologie',
  templateUrl: './ecologie.component.html',
  styleUrls: ['./ecologie.component.scss']
})
export class EcologieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
