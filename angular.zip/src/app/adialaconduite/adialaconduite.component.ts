import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adialaconduite',
  templateUrl: './adialaconduite.component.html',
  styleUrls: ['./adialaconduite.component.scss']
})
export class AdialaconduiteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
